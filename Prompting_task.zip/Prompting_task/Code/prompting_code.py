# logit_code.py

import os
import math
import numpy as np
import pandas as pd
import torch
import matplotlib.pyplot as plt

from transformers import (
    GPT2LMHeadModel, GPT2Tokenizer,
    BertForMaskedLM, BertTokenizer,
    RobertaForMaskedLM, RobertaTokenizer
)

# =========================================================
# REPRODUCIBILITY (IMPORTANT FOR THESIS)
# =========================================================

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# =========================================================
# OUTPUT DIRS
# =========================================================

save_dir = "./logits/results"
save_plot = "./logits/plots"

os.makedirs(save_dir, exist_ok=True)
os.makedirs(save_plot, exist_ok=True)

# =========================================================
# DATA GENERATION
# =========================================================

def generate_pairs(min_n=1, max_n=200, max_distance=20, samples_per_distance=5):
    pairs = []
    for d in range(1, max_distance + 1):
        for _ in range(samples_per_distance):
            i = np.random.randint(min_n + d, max_n - d)
            j = i + d if np.random.rand() < 0.5 else i - d
            pairs.append((i, j, d))
    return pairs


def compute_features(i, j):
    return abs(i - j), np.log(max(i, j) / min(i, j)), (i + j) / 2


def build_prompt(i, j):
    return f"A: {i}, B: {j}. The larger number is"

# =========================================================
# GPT-2 LOGPROB
# =========================================================

def gpt2_logprob(model, tokenizer, prompt, number):

    inputs = tokenizer(prompt, return_tensors="pt").to(DEVICE)
    input_ids = inputs["input_ids"][0]

    token_ids = tokenizer(" " + str(number), add_special_tokens=False)["input_ids"]

    full_ids = torch.tensor(
        input_ids.tolist() + token_ids,
        device=DEVICE
    ).unsqueeze(0)

    with torch.no_grad():
        outputs = model(full_ids)
        log_probs = torch.log_softmax(outputs.logits, dim=-1)

    total = 0.0
    prompt_len = len(input_ids)

    for t in range(len(token_ids)):
        pos = prompt_len + t - 1
        if pos >= 0:
            total += log_probs[0, pos, token_ids[t]].item()

    return total


def gpt2_choice(model, tokenizer, prompt, i, j):

    li = gpt2_logprob(model, tokenizer, prompt, i)
    lj = gpt2_logprob(model, tokenizer, prompt, j)

    probs = np.array([li, lj])
    probs = np.exp(probs - np.max(probs))
    probs /= probs.sum()

    return li, lj, probs[0], probs[1]

# =========================================================
# MLM (VALID + DEFENSIBLE VERSION)
# =========================================================

def is_single_token(tokenizer, number):
    return len(tokenizer.tokenize(str(number))) == 1


def mlm_choice(model, tokenizer, prompt, i, j):

    if not (is_single_token(tokenizer, i) and is_single_token(tokenizer, j)):
        return None, None, None, None

    text = f"{prompt} [MASK]"
    inputs = tokenizer(text, return_tensors="pt").to(DEVICE)

    mask_index = (inputs["input_ids"][0] == tokenizer.mask_token_id).nonzero(as_tuple=True)[0].item()

    with torch.no_grad():
        logits = model(**inputs).logits

    mask_logits = torch.log_softmax(logits[0, mask_index], dim=-1)

    li = mask_logits[tokenizer.convert_tokens_to_ids(str(i))].item()
    lj = mask_logits[tokenizer.convert_tokens_to_ids(str(j))].item()

    probs = np.array([li, lj])
    probs = np.exp(probs - np.max(probs))
    probs /= probs.sum()

    return li, lj, probs[0], probs[1]

# =========================================================
# EXPERIMENT
# =========================================================

def run_experiment(name, model, tokenizer, model_type, pairs):

    results = []
    model.eval()

    for i, j, d in pairs:

        prompt = build_prompt(i, j)
        distance, ratio, size = compute_features(i, j)

        try:
            if model_type == "causal":
                li, lj, pi, pj = gpt2_choice(model, tokenizer, prompt, i, j)
            else:
                li, lj, pi, pj = mlm_choice(model, tokenizer, prompt, i, j)

            if li is None:
                continue

            probs = np.array([pi, pj])
            probs /= probs.sum()

            entropy = -np.sum(probs * np.log(probs + 1e-12))

            pred = np.argmax(probs)
            correct = int(pred == (0 if i > j else 1))

            results.append({
                "model": name,
                "type": model_type,
                "i": i,
                "j": j,
                "distance": distance,
                "ratio": ratio,
                "size": size,
                "logprob_i": li,
                "logprob_j": lj,
                "prob_i": pi,
                "prob_j": pj,
                "entropy": entropy,
                "accuracy": correct
            })

        except Exception:
            continue

    return pd.DataFrame(results)

# =========================================================
# CONSISTENT BINNING (VERY IMPORTANT)
# =========================================================

def get_bins(df_all):

    return {
        "distance": np.linspace(1, 20, 11),
        "ratio": np.linspace(df_all["ratio"].min(), df_all["ratio"].max(), 11),
        "size": np.linspace(df_all["size"].min(), df_all["size"].max(), 11)
    }

# =========================================================
# PLOTS (CONSISTENT + REVIEWER SAFE)
# =========================================================

def plot_heatmap(df, model, bins):

    if df.empty:
        return

    pivot = df.pivot_table(
        values="entropy",
        index=pd.cut(df["distance"], bins=bins["distance"]),
        columns=pd.cut(df["size"], bins=bins["size"]),
        aggfunc="mean"
    )

    plt.figure()
    plt.imshow(pivot.values, aspect="auto", origin="lower")
    plt.colorbar(label="Entropy")

    plt.title(f"{model} - Distance vs Size Entropy")
    plt.xlabel("Size bins")
    plt.ylabel("Distance bins")

    plt.savefig(f"{save_plot}/{model}_heatmap.png", dpi=300)
    plt.close()


def plot_curve(df, model, col, bins):

    if df.empty:
        return

    df = df.copy()
    df["bin"] = pd.cut(df[col], bins=bins[col])

    agg = df.groupby("bin", observed=False)["entropy"].mean()

    plt.figure()
    plt.plot(agg.index.astype(str), agg.values, marker="o")

    plt.xticks(rotation=45)
    plt.title(f"{model} - Entropy vs {col}")
    plt.xlabel(col)
    plt.ylabel("Entropy")

    plt.tight_layout()
    plt.savefig(f"{save_plot}/{model}_{col}.png", dpi=300)
    plt.close()


def plot_model_comparison(df):

    agg = df.groupby("model")["entropy"].mean()

    plt.figure()
    plt.bar(agg.index, agg.values)
    plt.ylabel("Mean Entropy")
    plt.title("Model Comparison")

    plt.savefig(f"{save_plot}/model_comparison.png", dpi=300)
    plt.close()

# =========================================================
# LOAD MODELS
# =========================================================

def load_models():

    gpt2_tok = GPT2Tokenizer.from_pretrained("gpt2")
    gpt2 = GPT2LMHeadModel.from_pretrained("gpt2").to(DEVICE)
    gpt2_tok.pad_token = gpt2_tok.eos_token

    bert_tok = BertTokenizer.from_pretrained("bert-base-uncased")
    bert = BertForMaskedLM.from_pretrained("bert-base-uncased").to(DEVICE)

    roberta_tok = RobertaTokenizer.from_pretrained("roberta-base")
    roberta = RobertaForMaskedLM.from_pretrained("roberta-base").to(DEVICE)

    return [
        ("gpt2", gpt2, gpt2_tok, "causal"),
        ("bert", bert, bert_tok, "masked"),
        ("roberta", roberta, roberta_tok, "masked"),
    ]

# =========================================================
# MAIN
# =========================================================

if __name__ == "__main__":

    pairs = generate_pairs()
    models = load_models()

    all_dfs = []

    for name, model, tok, mtype in models:

        print(f"Running {name}...")

        df = run_experiment(name, model, tok, mtype, pairs)

        df.to_csv(f"{save_dir}/{name}_results.csv", index=False)

        all_dfs.append(df)

    full_df = pd.concat(all_dfs, ignore_index=True)

    bins = get_bins(full_df)

    for name in full_df["model"].unique():
        dfm = full_df[full_df["model"] == name]

        plot_heatmap(dfm, name, bins)
        plot_curve(dfm, name, "distance", bins)
        plot_curve(dfm, name, "ratio", bins)
        plot_curve(dfm, name, "size", bins)

    plot_model_comparison(full_df)

    print(full_df.groupby("model")["accuracy"].mean())
