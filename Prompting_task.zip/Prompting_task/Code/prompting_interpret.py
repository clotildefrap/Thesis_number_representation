# logit_interpret_fixed.py

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import seaborn as sns

# =========================================================
# STYLE (THESIS-READY)
# =========================================================

sns.set(style="whitegrid", context="talk")

# =========================================================
# PATHS
# =========================================================

DATA_DIR = "./logits/results"
OUT_DIR = "./logits_interpret"

os.makedirs(OUT_DIR, exist_ok=True)

# =========================================================
# LOAD DATA
# =========================================================

def load_all_results():

    files = [f for f in os.listdir(DATA_DIR) if f.endswith("_results.csv")]

    dfs = []

    for f in files:
        df = pd.read_csv(os.path.join(DATA_DIR, f))
        df["source_file"] = f
        dfs.append(df)

    return pd.concat(dfs, ignore_index=True)

# =========================================================
# CLEANING (STRICT)
# =========================================================

def clean(df):

    cols = ["entropy", "distance", "ratio", "size", "accuracy"]

    for c in cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")

    df = df.dropna(subset=["entropy", "accuracy", "distance"])

    return df

# =========================================================
# GLOBAL BINNING (CRITICAL FOR COMPARABILITY)
# =========================================================

def compute_bins(df):

    return {
        "distance": np.linspace(df["distance"].min(), df["distance"].max(), 11),
        "ratio": np.linspace(df["ratio"].min(), df["ratio"].max(), 11),
        "size": np.linspace(df["size"].min(), df["size"].max(), 11),
    }

# =========================================================
# SUMMARY STATISTICS
# =========================================================

def summary_stats(df):

    summary = df.groupby("model").agg(
        accuracy=("accuracy", "mean"),
        entropy=("entropy", "mean"),
        entropy_std=("entropy", "std"),
        n=("accuracy", "count")
    )

    summary.to_csv(os.path.join(OUT_DIR, "summary_stats.csv"))

    return summary

# =========================================================
# SMOOTH EFFECT PLOTS (CORRECT BINNING)
# =========================================================

def plot_effect(df, feature, bins):

    plt.figure(figsize=(8, 6))

    for model in df["model"].unique():

        sub = df[df["model"] == model].copy()
        sub["bin"] = pd.cut(sub[feature], bins=bins[feature])

        agg = sub.groupby("bin", observed=False)["entropy"].agg(["mean", "std", "count"])

        x = [b.mid for b in agg.index]
        y = agg["mean"].values
        se = agg["std"] / np.sqrt(agg["count"])

        plt.plot(x, y, label=model)
        plt.fill_between(x, y - se, y + se, alpha=0.2)

    plt.xlabel(feature.capitalize())
    plt.ylabel("Entropy")
    plt.title(f"Entropy vs {feature}")
    plt.legend()

    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, f"effect_{feature}.png"), dpi=300)
    plt.close()

# =========================================================
# ACCURACY VS DISTANCE (CLEAN VERSION)
# =========================================================

def accuracy_vs_distance(df, bins):

    plt.figure(figsize=(8, 6))

    for model in df["model"].unique():

        sub = df[df["model"] == model].copy()
        sub["bin"] = pd.cut(sub["distance"], bins=bins["distance"])

        agg = sub.groupby("bin", observed=False)["accuracy"].mean()

        x = [b.mid for b in agg.index]
        y = agg.values

        plt.plot(x, y, marker="o", label=model)

    plt.xlabel("Distance |i - j|")
    plt.ylabel("Accuracy")
    plt.title("Accuracy vs Distance")
    plt.legend()

    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "accuracy_distance.png"), dpi=300)
    plt.close()

# =========================================================
# MODEL COMPARISON
# =========================================================

def model_comparison(df):

    agg = df.groupby("model").agg(
        accuracy=("accuracy", "mean"),
        entropy=("entropy", "mean")
    ).reset_index()

    agg.to_csv(os.path.join(OUT_DIR, "model_ranking.csv"), index=False)

    plt.figure(figsize=(6, 6))

    sns.scatterplot(
        data=agg,
        x="entropy",
        y="accuracy",
        hue="model",
        s=120
    )

    plt.xlabel("Mean Entropy")
    plt.ylabel("Accuracy")
    plt.title("Model Trade-off")

    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "model_tradeoff.png"), dpi=300)
    plt.close()

# =========================================================
# CORRELATION (WITH WARNING FIX)
# =========================================================

def correlations(df):

    cols = ["distance", "ratio", "size", "entropy", "accuracy"]

    corr = df[cols].corr(numeric_only=True)

    corr.to_csv(os.path.join(OUT_DIR, "correlations.csv"))

    plt.figure(figsize=(7, 6))

    sns.heatmap(corr, annot=True, cmap="coolwarm", square=True)

    plt.title("Feature Correlation Matrix")

    plt.tight_layout()
    plt.savefig(os.path.join(OUT_DIR, "correlation_heatmap.png"), dpi=300)
    plt.close()

# =========================================================
# MAIN PIPELINE
# =========================================================

def main():

    df = load_all_results()
    df = clean(df)

    print("Loaded:", df.shape)

    bins = compute_bins(df)

    # stats
    print(summary_stats(df))

    # effects
    plot_effect(df, "distance", bins)
    plot_effect(df, "ratio", bins)
    plot_effect(df, "size", bins)

    accuracy_vs_distance(df, bins)

    correlations(df)

    model_comparison(df)

    print("\nSaved outputs to:", OUT_DIR)

# =========================================================

if __name__ == "__main__":
    main()
