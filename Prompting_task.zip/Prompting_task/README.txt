# Prompting_task

CODE

The scripts in the 'Code' folder are the ones used for our the additional experiment we ran and reported in the Appendix. They correspond to the main experiment and the statistical layer, respectively. This experiment consists in prompting the models with a comparison task expressed in natural language, for which the model is to predict which is the largest number in the given pair. We measure accuracy, entropy, and calculate the size, distance, and ratio effects corresponding to each number pair before correlating their results to the performance of the model. This aims at investigating whether the behavioural performance of the models produce the same effects as humans when processing numbers. Additionally, this complements our first experiment in which we measure the presence of these effects directly in the embedding space of the models. Thus, we are trying to decipher whether behavioural performance reflects internal organisation


PLOTS


The plots generated show the Entropy vs Distance curve, that is how average entropy changes as the numerical distance between the two numbers increases. Values are grouped into bins, and entropy is averaged within each bin. It captures whether models become more or less confident when distinguishing numbers that are close together versus far apart. The Entropy vs Ratio curve, illustrates the relationship between entropy and the ratio between the two numbers (max/min). It evaluates whether relative scale differences (rather than absolute distance) influence model uncertainty in choosing the larger number. The Entropy vs Size curve shows how entropy varies with the average magnitude of the number pair. It tests whether models behave differently when comparing small numbers versus large numbers, even when their relative difference is similar.
The Feature correlation heatmap shows pairwise correlations between numerical features (distance, ratio, size) and model outputs (entropy, accuracy). It helps identify dependencies between input structure and model behaviour, such as whether entropy is more strongly driven by absolute distance or relative ratio effects.
Lastly, the Accuracy vs distance plot shows how classification accuracy changes as the numerical distance between two numbers increases. Values are binned over ∣i−j∣ and averaged per model. It directly measures the expected behavioural pattern that larger numerical gaps make comparisons easier, resulting in higher accuracy.

RESULTS

The results summarise our findings, per model, on average, the correlations between accurace and entropy and effects, and the statistical results.
